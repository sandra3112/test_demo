package ro.digitalnation.activitati;

public interface Activitate {
	
	public String getDescriere();
	public String getDurata();
}
